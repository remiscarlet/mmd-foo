「Kimi iro ni Somaru」 Camera Motion Download

Hi, remidapyon here. This is my first camera motion so apologies for any issues you may find. 

This camera motion was created using つん's dance motion as a baseline.
https://www.nicovideo.jp/watch/sm28422307

There are no particular restrictions on the usage of this file. Please feel free to use as you see fit.

2020/06/03 remidapyon